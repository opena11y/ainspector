/* options-general.js */

// Imports

import DebugLogging  from './debug.js';

import {
  getOptions,
  saveOptions,
  resetGeneralOptions
} from './storage.js';

import {
  setI18nLabels
} from './utils.js';

// Constants

const debug = new DebugLogging('[options-general]', false);
debug.flag = false;

const optionsGeneralTemplate = document.createElement('template');
optionsGeneralTemplate.innerHTML = `
  <form class="options">
    <fieldset>
      <legend data-i18n="options_general_rule_results_legend">
        Rule Results
      </legend>
      <label>
        <input type="checkbox"
               data-option="resultsIncludePassNa"/>
        <span data-i18n="options_general_incl_pass_na_label">
          Include 'Pass' and 'N/A' results
        </span>
      </label>
    </fieldset>

    <fieldset>
      <legend data-i18n="option_general_rerun_evaluation_legend">'
        Rerun Evaluation' Button
      </legend>
      <label>
        <input type="radio"
               name="delay"
               value="false"
               data-option="rerunDelayEnabled"
               data-option-checked="false"/>
        <span data-i18n="options_general_no_delay_label">
          Rerun with no delay
        </span>
      </label>
      <label>
        <input type="radio"
              name="delay"
              value="true"
              data-option="rerunDelayEnabled"
               data-option-checked="true"/>
        <span data-i18n="options_general_prompt_for_delay_label">
          Prompt for delay setting
        </span>
      </label>
    </fieldset>

    <fieldset>
      <legend data-i18n="options_general_views_menu_legend">
        'Views' menu
      </legend>
      <label>
        <input type="Checkbox"
               data-option="viewsMenuIncludeGuidelines"/>
        <span id="options_general_incl_wcag_gl_label">
          Include WCAG Guidelines
        </span>
      </label>
    </fieldset>

    <button id="button-reset"
            type="reset"
            data-i18n="options_reset_general_defaults_button">
            Reset General Defaults
    </button>

  </form>
`;

class OptionsGeneral extends HTMLElement {

  constructor() {

    super();

    this.attachShadow({ mode: 'open' });
    // const used for help function

    const optionsGeneral = this;

    const optionsGeneralClone = optionsGeneralTemplate.content.cloneNode(true);
    this.shadowRoot.appendChild(optionsGeneralClone);

    // Use external CSS stylesheets
    let link = document.createElement('link');
    link.setAttribute('rel', 'stylesheet');
    link.setAttribute('href', 'base.css');
    this.shadowRoot.appendChild(link);

    link = document.createElement('link');
    link.setAttribute('rel', 'stylesheet');
    link.setAttribute('href', 'options.css');
    this.shadowRoot.appendChild(link);

    setI18nLabels(this.shadowRoot, debug.flag);

    this.formControls =  Array.from(this.shadowRoot.querySelectorAll('[data-option]'));

    this.updateOptions();

    this.shadowRoot.querySelector('#button-reset').addEventListener('click', () => {
      resetGeneralOptions().then(this.updateOptions.bind(this));
    });

    optionsGeneral.shadowRoot.querySelectorAll('input[type=checkbox], input[type=radio]').forEach( input => {
      input.addEventListener('focus',  optionsGeneral.handleFocus);
      input.addEventListener('blur',   optionsGeneral.handleBlur);
      input.addEventListener('change', optionsGeneral.handleChange.bind(optionsGeneral));
      input.parentNode.addEventListener('blur',   optionsGeneral.handlePointerover);
    });

    this.handleResize();
    window.addEventListener('resize', this.handleResize.bind(this));
  }

  updateOptions () {
    const formControls = this.formControls;

    getOptions().then( (options) => {

      formControls.forEach( input => {
        debug.flag && console.log(`[update][${input.id}]: ${options[input.getAttribute('data-option')]} (${input.getAttribute('data-option')})`);

        const option = input.getAttribute('data-option');

        if (input.type === 'checkbox') {
          input.checked = options[option];
        }
        else {
          if (input.type === 'radio') {
            const checkedValue = input.getAttribute('data-option-checked');
            const value = options[option] ? 'true' : 'false';
            input.checked = checkedValue === value;
          }
          else {
            input.value = options[option];
          }
        }
      });
    });
  }

  saveGeneralOptions () {
   const formControls = this.formControls;
  getOptions().then( (options) => {

      formControls.forEach( input => {
        debug.flag && console.log(`[update][${input.id}]: ${options[input.getAttribute('data-option')]} (${input.getAttribute('data-option')})`);
        const option = input.getAttribute('data-option');
        if (input.type === 'checkbox') {
          options[option] = input.checked;
        }
        else {
          if (input.type === 'radio') {
            if (input.checked) {
              const checkedValue = input.getAttribute('data-option-checked');
              options[option] = checkedValue === 'true';
            }
          }
          else {
            if (input.type === 'text') {
             options[option] = input.value;
            }
          }
        }
      });
      saveOptions(options);
    });
  }

  // Event handlers

  handleFocus (event) {
    const pNode = event.currentTarget.parentNode;
    pNode.classList.add('focus');
    const rect = pNode.querySelector('span').getBoundingClientRect();
    pNode.style.width = (rect.width + 40) + 'px';
  }

  handlePointerover (event) {
    const pNode = event.currentTarget;
    const rect = pNode.querySelector('span').getBoundingClientRect();
    pNode.style.width = (rect.width + 40) + 'px';
  }

  handleBlur (event) {
    event.currentTarget.parentNode.classList.remove('focus');
  }

  handleChange () {
    debug && console.log(`[saveOptions]`);
    this.saveGeneralOptions();
  }

  handleResize() {
    this.shadowRoot.querySelectorAll('input[type=radio], input[type=checkbox]').forEach( input => {
      const node = input.parentNode;
      if (node) {
        node.style.width = 'auto';
      }
    });
  }
}

window.customElements.define("options-general", OptionsGeneral);
